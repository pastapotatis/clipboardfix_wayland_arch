#!/bin/bash

HYPR_MARK_BEGIN="# >>> wayland-spice-clipboard (managed block) >>>"
HYPR_MARK_END="# <<< wayland-spice-clipboard (managed block) <<<"

echo "Removing Wayland SPICE clipboard fix (Arch/Omarchy)..."

systemctl --user stop wayland-spice-clipboard.service spice-vdagent-user.service 2>/dev/null || true
systemctl --user disable wayland-spice-clipboard.service spice-vdagent-user.service 2>/dev/null || true

rm -f ~/.config/systemd/user/wayland-spice-clipboard.service
rm -f ~/.config/systemd/user/spice-vdagent-user.service

# Remove our XDG override only if it is ours (restores the distro autostart entry)
if grep -q "managed by spice-vdagent-user.service" ~/.config/autostart/spice-vdagent.desktop 2>/dev/null; then
    rm -f ~/.config/autostart/spice-vdagent.desktop
fi

# Remove the Hyprland exec-once block if we added one
for f in ~/.config/hypr/autostart.conf ~/.config/hypr/hyprland.conf; do
    if [ -f "$f" ] && grep -qF "$HYPR_MARK_BEGIN" "$f"; then
        sed -i "/^$(printf '%s' "$HYPR_MARK_BEGIN" | sed 's/[]\/$*.^[]/\\&/g')\$/,/^$(printf '%s' "$HYPR_MARK_END" | sed 's/[]\/$*.^[]/\\&/g')\$/d" "$f"
        echo "Removed exec-once block from $f"
    fi
done

sudo rm -f /usr/local/bin/wayland-spice-clipboard /usr/local/bin/fix-clipboard

systemctl --user daemon-reload

echo "Removal complete"
echo "Note: packages (wl-clipboard, xclip, spice-vdagent) and spice-vdagentd left installed"
