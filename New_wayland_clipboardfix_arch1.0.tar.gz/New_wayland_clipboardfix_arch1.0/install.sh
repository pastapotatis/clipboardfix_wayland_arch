#!/bin/bash
#
# Installer for the Arch/Omarchy (Hyprland) port. Run INSIDE the guest VM,
# as your normal user (it will sudo where needed).
set -e

cd "$(dirname "$(readlink -f "$0")")"

HYPR_MARK_BEGIN="# >>> wayland-spice-clipboard (managed block) >>>"
HYPR_MARK_END="# <<< wayland-spice-clipboard (managed block) <<<"

echo "Installing Wayland SPICE clipboard fix (Arch/Omarchy)..."

if [ "$(id -u)" -eq 0 ]; then
    echo "Run this as your normal user, not root." >&2
    exit 1
fi

# --- Guard: this belongs in the guest, not the host ---
virt="$(systemd-detect-virt 2>/dev/null || echo none)"
if [ "$virt" = "none" ]; then
    echo "WARNING: this machine does not look like a VM (systemd-detect-virt = none)."
    echo "The bridge must run in the GUEST. On the host it does nothing useful."
    read -p "Continue anyway? (y/N) " -n 1 -r; echo
    [[ $REPLY =~ ^[Yy]$ ]] || exit 1
fi

if [ "${XDG_SESSION_TYPE:-}" != "wayland" ]; then
    echo "Warning: XDG_SESSION_TYPE is '${XDG_SESSION_TYPE:-unset}', not wayland"
    read -p "Continue? (y/N) " -n 1 -r; echo
    [[ $REPLY =~ ^[Yy]$ ]] || exit 1
fi

echo "Installing dependencies..."
sudo pacman -S --needed --noconfirm wl-clipboard xclip spice-vdagent

echo "Installing bridge script..."
sudo install -m 0755 scripts/wayland-spice-clipboard /usr/local/bin/wayland-spice-clipboard
sudo install -m 0755 scripts/fix-clipboard /usr/local/bin/fix-clipboard

echo "Installing user services..."
mkdir -p ~/.config/systemd/user
cp systemd/wayland-spice-clipboard.service ~/.config/systemd/user/
cp systemd/spice-vdagent-user.service ~/.config/systemd/user/

# The spice-vdagent package ships an XDG autostart entry. Under uwsm that would
# start a SECOND user agent next to ours. Hide it for this user (standard XDG
# override, the system file is untouched).
if [ -f /etc/xdg/autostart/spice-vdagent.desktop ]; then
    mkdir -p ~/.config/autostart
    cat > ~/.config/autostart/spice-vdagent.desktop <<'EOD'
[Desktop Entry]
Type=Application
Name=SPICE vdagent (disabled, managed by spice-vdagent-user.service)
Hidden=true
EOD
fi

systemctl --user daemon-reload
systemctl --user enable spice-vdagent-user.service wayland-spice-clipboard.service

echo "Enabling spice-vdagentd (system daemon)..."
if systemctl cat spice-vdagentd.socket >/dev/null 2>&1; then
    sudo systemctl enable --now spice-vdagentd.socket
fi
sudo systemctl enable spice-vdagentd.service 2>/dev/null || true
sudo systemctl restart spice-vdagentd.service || \
    echo "Note: spice-vdagentd did not start — is the SPICE channel (com.redhat.spice.0) present in the VM?"

# --- Make sure the user services actually start under Hyprland ---
# With uwsm (Omarchy default) graphical-session.target is reached and the units
# above start by themselves. Without uwsm, nothing activates that target, so we
# add a small exec-once block to the Hyprland config instead.
if systemctl --user is-active --quiet graphical-session.target; then
    echo "graphical-session.target is active (uwsm) — services will start with the session."
    systemctl --user restart spice-vdagent-user.service wayland-spice-clipboard.service
else
    hypr_conf=""
    for f in ~/.config/hypr/autostart.conf ~/.config/hypr/hyprland.conf; do
        [ -f "$f" ] && { hypr_conf="$f"; break; }
    done
    if [ -n "$hypr_conf" ]; then
        if ! grep -qF "$HYPR_MARK_BEGIN" "$hypr_conf"; then
            echo "graphical-session.target not active — adding exec-once block to $hypr_conf"
            cat >> "$hypr_conf" <<EOD

$HYPR_MARK_BEGIN
exec-once = systemctl --user import-environment WAYLAND_DISPLAY DISPLAY XDG_RUNTIME_DIR && systemctl --user start spice-vdagent-user.service wayland-spice-clipboard.service
$HYPR_MARK_END
EOD
        fi
    else
        echo "WARNING: no uwsm session and no Hyprland config found."
        echo "Start the services from your compositor's autostart with:"
        echo "  systemctl --user import-environment WAYLAND_DISPLAY DISPLAY XDG_RUNTIME_DIR"
        echo "  systemctl --user start spice-vdagent-user.service wayland-spice-clipboard.service"
    fi
    # Start now for the current session
    systemctl --user import-environment WAYLAND_DISPLAY DISPLAY XDG_RUNTIME_DIR 2>/dev/null || true
    systemctl --user restart spice-vdagent-user.service wayland-spice-clipboard.service
fi

echo ""
echo "Installation complete!"
echo "Check status:  systemctl --user status wayland-spice-clipboard spice-vdagent-user"
echo "Monitor logs:  journalctl --user -u wayland-spice-clipboard -f"
echo "If it breaks:  fix-clipboard --test"
