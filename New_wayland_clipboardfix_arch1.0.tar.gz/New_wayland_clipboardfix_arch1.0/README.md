# New_wayland_clipboardfix_arch 1.0

Arch Linux / Omarchy (Hyprland) port of
[chrisbelson/wayland-spice-clipboard-fix](https://github.com/chrisbelson/wayland-spice-clipboard-fix),
plus the `fix-clipboard` recovery tool.

**Install this inside the guest VM**, not on the host. The host side
(virt-manager / virt-viewer) needs nothing from this package.

## Pipeline

```
Wayland clipboard (Hyprland)
  -> wayland-spice-clipboard  (polls wl-paste, writes with xclip)
  -> XWayland CLIPBOARD
  -> spice-vdagent (user agent)  -> spice-vdagentd  -> virtio-serial -> host
```

Host -> guest goes spice-vdagent -> XWayland -> Hyprland's own X11/Wayland
clipboard sync. The bridge is not involved in that direction.

## Differences from the original / the Parrot port

| | Original / Parrot | Arch / Omarchy |
|---|---|---|
| Packages | dnf / apt-get | `pacman -S --needed wl-clipboard xclip spice-vdagent` |
| Wayland socket | hardcoded `wayland-0` | inherited from session, then systemd env, then first socket found (Hyprland normally uses `wayland-1`) |
| X11 display | `xset` probing | inherited, then systemd env, then `/tmp/.X11-unix` (no `xorg-xset` needed) |
| spice-vdagent user agent | `.desktop` autostart with `nohup` | systemd user unit `spice-vdagent-user.service` (supervised, restartable) |
| Distro autostart entry | left active | hidden per-user so only one user agent runs |
| Session start | `default.target` | `graphical-session.target` (uwsm); exec-once fallback in Hyprland config if uwsm is not used |
| Sleep/resume hook | (Parrot: optional) | not included |

The bridge loop itself is unchanged from the original.

## Install

```
chmod +x install.sh uninstall.sh scripts/*
./install.sh
```

Run as your normal user. The installer:

- warns if `systemd-detect-virt` says you are not in a VM
- installs packages with pacman
- installs `/usr/local/bin/wayland-spice-clipboard` and `/usr/local/bin/fix-clipboard`
- installs and enables the two user units
- hides `/etc/xdg/autostart/spice-vdagent.desktop` for your user (`~/.config/autostart/spice-vdagent.desktop`, `Hidden=true`)
- enables and restarts `spice-vdagentd`
- if `graphical-session.target` is not active (no uwsm), appends a clearly
  marked `exec-once` block to `~/.config/hypr/autostart.conf` (or `hyprland.conf`)

`./uninstall.sh` reverses all of the above and leaves the packages installed.

## When the clipboard breaks

```
fix-clipboard --test   # restart user agent only, asks if it helped, escalates if not
fix-clipboard          # full: kill stray xclip, restart vdagentd, user agent, bridge
fix-clipboard --diag   # show state only
```

The built-in check only proves the XWayland clipboard round-trip. Whether the
host link works can only be confirmed by actually pasting on the host — that is
why `--test` asks you.

## Requirements on the VM

- SPICE display and the `com.redhat.spice.0` agent channel (virt-manager default)
- Hyprland with XWayland enabled (default)

## Known limitation (inherited from the original)

`$(wl-paste ...)` strips trailing newlines, so `secret\n` arrives on the host
as `secret`. Fine for most use; not byte-exact.
